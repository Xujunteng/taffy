import { defineStore } from 'pinia'
import { api } from '@/api'
export const useAppStore=defineStore('app',{state:()=>({voices:[],scripts:[],feedbacks:[],helpArticles:[],stats:null}),actions:{async loadAll(){await Promise.allSettled([this.loadVoices(),this.loadScripts(),this.loadFeedbacks(),this.loadHelp(),this.loadStats()])},async loadVoices(){this.voices=await api.voices()},async loadScripts(){this.scripts=await api.scripts()},async loadFeedbacks(){this.feedbacks=await api.feedbacks()},async loadHelp(){this.helpArticles=await api.help()},async loadStats(){this.stats=await api.stats()}}})
