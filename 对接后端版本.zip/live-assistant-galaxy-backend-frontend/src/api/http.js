import axios from 'axios'
import { ElMessage } from 'element-plus'
import { useAuthStore } from '@/stores/auth'
import { mockRequest } from './mock'
const useMock = String(import.meta.env.VITE_USE_MOCK).toLowerCase() === 'true'
export const http = axios.create({ baseURL: import.meta.env.VITE_API_BASE || '/api', timeout: 30000 })
function unwrap(payload){if(payload&&typeof payload==='object'){if('code'in payload && ![0,200,'0','200'].includes(payload.code))throw new Error(payload.message||payload.msg||'请求失败');if(payload.success===false)throw new Error(payload.message||payload.msg||'请求失败');if('data'in payload && Object.keys(payload).some(k=>['code','success','message','msg'].includes(k)))return payload.data}return payload}
http.interceptors.request.use(config=>{const auth=useAuthStore();config.headers=config.headers||{};if(auth.token)config.headers.Authorization=`Bearer ${auth.token}`;if(config.data instanceof FormData)delete config.headers['Content-Type'];return config})
http.interceptors.response.use(r=>unwrap(r.data),e=>{const msg=e.response?.data?.message||e.response?.data?.msg||e.message||'请求失败';if(e.response?.status===401){useAuthStore().logout(false);ElMessage.error('登录已过期，请重新登录')}else ElMessage.error(msg);return Promise.reject(e)})
export function request(config){return useMock?mockRequest(config):http(config)}
