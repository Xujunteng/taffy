import { request } from './http'
export const api={
 login:data=>request({url:'/auth/login',method:'post',data}), register:data=>request({url:'/auth/register',method:'post',data}),
 voices:()=>request({url:'/voices',method:'get'}), createVoice:data=>request({url:'/voices',method:'post',data}), deleteVoice:id=>request({url:`/voices/${id}`,method:'delete'}),
 uploadAudio:data=>request({url:'/audio/upload',method:'post',data}), trainVoice:data=>request({url:'/voice/train',method:'post',data}),
 tts:data=>request({url:'/tts/convert',method:'post',data}), ttsStatus:id=>request({url:`/tts/status/${id}`,method:'get'}),
 scripts:()=>request({url:'/scripts',method:'get'}), saveScript:data=>request({url:'/scripts',method:'post',data}), updateScript:(id,data)=>request({url:`/scripts/${id}`,method:'put',data}), deleteScript:id=>request({url:`/scripts/${id}`,method:'delete'}),
 feedbacks:()=>request({url:'/feedback',method:'get'}), addFeedback:data=>request({url:'/feedback',method:'post',data}), stats:()=>request({url:'/stats/live',method:'get'}), help:()=>request({url:'/help/articles',method:'get'})
}
