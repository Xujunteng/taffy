import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import Layout from '@/views/Layout.vue'

const routes = [
  { path: '/login', component: () => import('@/views/Login.vue'), meta: { public: true } },
  { path: '/register', component: () => import('@/views/Register.vue'), meta: { public: true } },
  { path: '/', component: Layout, children: [
    { path: '', redirect: '/dashboard' },
    { path: 'dashboard', component: () => import('@/views/Dashboard.vue'), meta: { title: '首页工作台' } },
    { path: 'voices', component: () => import('@/views/Voices.vue'), meta: { title: '声音训练' } },
    { path: 'tts', component: () => import('@/views/TTS.vue'), meta: { title: '文本转语音' } },
    { path: 'live', component: () => import('@/views/Live.vue'), meta: { title: '直播面板' } },
    { path: 'scripts', component: () => import('@/views/Scripts.vue'), meta: { title: '脚本管理' } },
    { path: 'feedback', component: () => import('@/views/Feedback.vue'), meta: { title: '评价反馈' } },
    { path: 'stats', component: () => import('@/views/Stats.vue'), meta: { title: '数据统计' } },
    { path: 'help', component: () => import('@/views/Help.vue'), meta: { title: '帮助中心' } },
    { path: 'api-docs', component: () => import('@/views/ApiDocs.vue'), meta: { title: 'API文档' } }
  ] },
  { path: '/:pathMatch(.*)*', redirect: '/dashboard' }
]
const router = createRouter({ history: createWebHistory(), routes })
router.beforeEach(to => {
  const auth = useAuthStore()
  if (!to.meta.public && !auth.token) return '/login'
})
export default router
