# 直播助手 Galaxy 前端（可对接后端）

这是标准 Vue 3 + Vite 工程版，不是直接打开版。界面参考你给的深色星空/霓虹 UI，功能保留之前前端要求：登录注册、声音训练、音频上传/录音、TTS、直播面板、脚本管理、反馈评价、数据统计、帮助中心、API 文档。

## 启动

```bash
npm install
cp .env.example .env
npm run dev
```

访问：`http://localhost:5173`

## 对接后端

`.env` 中设置：

```env
VITE_USE_MOCK=false
VITE_API_BASE=/api
VITE_MAIN_BACKEND=http://localhost:8081
VITE_AI_BACKEND=http://localhost:8082
VITE_EXT_BACKEND=http://localhost:8083
```

代理规则：

- `/api/auth`、`/api/users`、`/api/voices` → 8081
- `/api/audio`、`/api/voice`、`/api/tts` → 8082
- `/api/scripts`、`/api/feedback`、`/api/stats`、`/api/help` → 8083

## Mock 演示

把 `.env` 改成：

```env
VITE_USE_MOCK=true
```

## 构建

```bash
npm run build
```

本包已完成构建检查。
